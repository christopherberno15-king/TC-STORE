# TC STORE · Android build phase

Android-first marketplace for Android apps. iOS, payments, and paid distribution are intentionally deferred as requested.

## Included in this phase
- Expo React Native Android client with dark marketplace UI.
- Account registration and login using bcrypt password hashes and short-lived JWTs.
- Creator application submission.
- Creator dashboard with APK upload (150 MB maximum), SHA-256 calculation, and APK ZIP-container signature check.
- Admin/Moderator review queue for submitted apps. Admin/Owner can approve or reject Creator applications.
- Server-side role checks and audit records.
- PostgreSQL persistence through Prisma.

**Important:** APK signature/container checks and SHA-256 are not antivirus scanning. New uploads remain unlisted until a human moderator/admin reviews them. Production should add a dedicated malware-scanning service and private object storage before accepting public uploads.

## 1. Requirements
- Node.js 20+
- PostgreSQL 15+
- Android device or emulator
- Android build tooling / Expo EAS for APK builds

## 2. Configure backend
```bash
cd backend
npm install
cp ../.env.example .env
# Set DATABASE_URL and a random JWT_SECRET of at least 32 characters.
npm run db:generate
npm run db:push
npm run dev
```

Set `UPLOAD_DIR` to a persistent private directory. Do not expose the upload folder as static public content.

## 3. Configure mobile client
Set `EXPO_PUBLIC_API_URL` to the reachable backend address before starting Expo. For Android emulator use `http://10.0.2.2:4000`; for a physical phone use the computer's LAN IP while both devices are on the same trusted network. Use HTTPS in production.
```bash
cd mobile
npm install
npx expo start
```

## 4. Build Android APK
Install EAS CLI and authenticate with your own Expo account, then:
```bash
cd mobile
eas build:configure
eas build --platform android --profile preview
```
The generated APK is provided by Expo's build service. A release build requires a proper signing configuration. No APK is included in this source archive.

## 5. Set the first Owner safely
Public registration always creates a `USER`. It is not possible to self-select Creator/Admin/Owner from the app. After creating the trusted owner's account, promote that exact account once using a protected database administration session:
```sql
UPDATE "User" SET role = 'OWNER', verified = true WHERE email = 'YOUR_OWNER_EMAIL';
```
Do not expose database credentials or an owner-promotion endpoint to the mobile client.

## Main API
- `GET /health`
- `GET /api/products`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/me`
- `POST /api/creator/apply`
- `POST /api/creator/products` (multipart field `apk`)
- `GET /api/creator/me`
- `GET /api/admin/queue`
- `POST /api/admin/products/:id/review`
- `POST /api/admin/creators/:id/review`
- `GET /api/admin/audit`

## Deliberately deferred
Payments, iOS app, AAB/Play Store publishing automation, and external antivirus integration are not part of this Android phase.


## Android build and backend deployment

### Build an installable Android APK (cloud build)

The mobile project uses Expo SDK 54. From `mobile/`, install dependencies and authenticate with Expo/EAS, then run:

```bash
npm install
npx eas-cli login
npx eas-cli build --platform android --profile preview
```

The `preview` profile outputs an installable APK. The `production` profile outputs an Android App Bundle (AAB) for a Play Store release. Set `EXPO_PUBLIC_API_URL` to the public HTTPS address of the deployed API before building. Do not use the emulator-only default `http://10.0.2.2:4000` for a phone release.

### Start PostgreSQL and the API with Docker

Copy `.env.production.example` to `.env`, set unique random secrets, then run from the repository root:

```bash
docker compose up -d --build
docker compose exec api npx prisma db push --schema database/schema.prisma
```

Create the first Owner account once the database is ready. Add `OWNER_EMAIL`, `OWNER_PASSWORD` (at least 14 characters), and optionally `OWNER_DISPLAY_NAME` to the API environment, then run:

```bash
docker compose exec api npx tsx scripts/create-owner.ts
```

Remove the temporary owner password from the environment after creating the account. Never share credentials in chat or commit `.env`.

### Current verification boundaries

The upload endpoint checks the APK ZIP container signature and records SHA-256. This is an integrity fingerprint, **not** malware detection or a guarantee that an APK is safe. Human Admin review remains mandatory. Before public production, add a dedicated malware scanning service, private object storage, HTTPS reverse proxy, backups, monitoring, and a distributed rate limiter.
