import 'dotenv/config';
import { PrismaClient, Role } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const email = process.env.OWNER_EMAIL?.trim().toLowerCase();
  const password = process.env.OWNER_PASSWORD;
  const displayName = process.env.OWNER_DISPLAY_NAME?.trim() || 'TC STORE Owner';
  if (!email || !password || password.length < 14) {
    throw new Error('Set OWNER_EMAIL and OWNER_PASSWORD (at least 14 characters) in the backend environment.');
  }
  const passwordHash = await bcrypt.hash(password, 12);
  const owner = await prisma.user.upsert({
    where: { email },
    update: { role: Role.OWNER, verified: true, passwordHash, displayName },
    create: { email, passwordHash, displayName, role: Role.OWNER, verified: true },
    select: { id: true, email: true, displayName: true, role: true },
  });
  console.log(`Owner account ready: ${owner.email} (${owner.role}). Remove OWNER_PASSWORD from the environment after setup.`);
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(async () => prisma.$disconnect());
