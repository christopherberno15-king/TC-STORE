import 'dotenv/config';
import express, { type Request, type Response, type NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { PrismaClient, ProductStatus, Role } from '@prisma/client';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import jwt, { type JwtPayload } from 'jsonwebtoken';
import multer from 'multer';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const app = express();
const prisma = new PrismaClient();
const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.JWT_SECRET;
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || 'uploads');
if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error('JWT_SECRET must be configured with at least 32 characters.');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
app.use(helmet());
app.use(cors({ origin: (process.env.ALLOWED_ORIGINS || '').split(',').filter(Boolean) }));
app.use(express.json({ limit: '32kb' }));

// Basic per-process abuse throttling. Put a production reverse-proxy/WAF in front for distributed deployments.
const rateBuckets = new Map<string, { count: number; resetAt: number }>();
const throttle = (limit: number, windowMs: number) => (req: Request, res: Response, next: NextFunction) => {
  const key = `${req.ip}:${req.path}`; const now = Date.now(); const bucket = rateBuckets.get(key);
  if (!bucket || bucket.resetAt <= now) rateBuckets.set(key, { count: 1, resetAt: now + windowMs });
  else if (++bucket.count > limit) return res.status(429).json({ error: 'Too many requests. Try again later.' });
  next();
};

interface AuthRequest extends Request { auth?: { id: string; role: Role } }
const authenticate = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Authentication required' });
  try {
    const payload = jwt.verify(token, JWT_SECRET!, { issuer: 'tc-store' }) as JwtPayload;
    if (typeof payload.sub !== 'string' || !Object.values(Role).includes(payload.role as Role)) throw new Error('Invalid token');
    const current = await prisma.user.findUnique({ where: { id: payload.sub }, select: { id: true, role: true } });
    if (!current) return res.status(401).json({ error: 'Account no longer exists' });
    // Always use the current database role, not a possibly stale role claim in the JWT.
    req.auth = { id: current.id, role: current.role }; next();
  } catch { return res.status(401).json({ error: 'Session expired or invalid' }); }
};
const allow = (...roles: Role[]) => (req: AuthRequest, res: Response, next: NextFunction) => {
  if (!req.auth || !roles.includes(req.auth.role)) return res.status(403).json({ error: 'Insufficient permissions' });
  next();
};
const audit = (actorId: string, action: string, entityType: string, entityId?: string, details?: object) =>
  prisma.auditLog.create({ data: { actorId, action, entityType, entityId, details: details as any } });

app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'tc-store-api' }));
app.get('/api/products', async (req, res) => {
  try {
    const q = String(req.query.q || '').slice(0, 80); const category = String(req.query.category || '').slice(0, 40);
    const items = await prisma.product.findMany({ where: { status: ProductStatus.PUBLISHED, ...(category ? { category } : {}), ...(q ? { OR: [{ name: { contains: q, mode: 'insensitive' } }, { description: { contains: q, mode: 'insensitive' } }] } : {}) }, select: { id: true, name: true, description: true, category: true, platforms: true, iconUrl: true, downloadUrl: true, creator: { select: { displayName: true, verified: true } } }, orderBy: { createdAt: 'desc' }, take: 50 });
    res.json({ items });
  } catch { res.status(500).json({ error: 'Unable to load products' }); }
});
const registerSchema = z.object({ email: z.string().email().max(254), password: z.string().min(10).max(72), displayName: z.string().min(2).max(40) });
app.post('/api/auth/register', throttle(5, 15 * 60 * 1000), async (req, res) => {
  const parsed = registerSchema.safeParse(req.body); if (!parsed.success) return res.status(400).json({ error: 'Invalid registration details' });
  try {
    const passwordHash = await bcrypt.hash(parsed.data.password, 12);
    const user = await prisma.user.create({ data: { email: parsed.data.email.toLowerCase(), passwordHash, displayName: parsed.data.displayName } });
    const token = jwt.sign({ sub: user.id, role: user.role }, JWT_SECRET!, { expiresIn: '2h', issuer: 'tc-store' });
    res.status(201).json({ token, user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role } });
  } catch { res.status(409).json({ error: 'Account could not be created. Email may already be registered.' }); }
});
app.post('/api/auth/login', throttle(10, 15 * 60 * 1000), async (req, res) => {
  const parsed = z.object({ email: z.string().email(), password: z.string().min(1).max(72) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid login details' });
  const user = await prisma.user.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
  if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) return res.status(401).json({ error: 'Invalid email or password' });
  const token = jwt.sign({ sub: user.id, role: user.role }, JWT_SECRET!, { expiresIn: '2h', issuer: 'tc-store' });
  res.json({ token, user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role } });
});
app.get('/api/me', authenticate, async (req: AuthRequest, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.auth!.id }, select: { id: true, email: true, displayName: true, role: true, verified: true } });
  if (!user) return res.status(404).json({ error: 'User not found' }); res.json({ user });
});

app.post('/api/creator/apply', authenticate, async (req: AuthRequest, res) => {
  const parsed = z.object({ displayName: z.string().min(2).max(40), projectDescription: z.string().min(30).max(1500) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Provide a creator name and at least 30 characters describing your work.' });
  if ([Role.CREATOR, Role.MODERATOR, Role.ADMIN, Role.OWNER].includes(req.auth!.role)) return res.status(409).json({ error: 'This account already has creator or staff access.' });
  const pending = await prisma.creatorApplication.findFirst({ where: { userId: req.auth!.id, status: 'PENDING' } });
  if (pending) return res.status(409).json({ error: 'You already have a pending application.' });
  const application = await prisma.creatorApplication.create({ data: { userId: req.auth!.id, ...parsed.data } });
  await audit(req.auth!.id, 'CREATOR_APPLICATION_SUBMITTED', 'CreatorApplication', application.id);
  res.status(201).json({ application });
});
app.get('/api/creator/me', authenticate, allow(Role.CREATOR, Role.MODERATOR, Role.ADMIN, Role.OWNER), async (req: AuthRequest, res) => {
  const products = await prisma.product.findMany({ where: { creatorId: req.auth!.id }, orderBy: { createdAt: 'desc' } }); res.json({ products });
});

const upload = multer({ dest: UPLOAD_DIR, limits: { fileSize: 150 * 1024 * 1024, files: 1 }, fileFilter: (_req, file, cb) => {
  if (path.extname(file.originalname).toLowerCase() !== '.apk' || !['application/vnd.android.package-archive', 'application/octet-stream', 'application/zip'].includes(file.mimetype)) return cb(new Error('Only Android APK files are accepted in this version.'));
  cb(null, true);
} });
app.post('/api/creator/products', throttle(10, 60 * 60 * 1000), authenticate, allow(Role.CREATOR, Role.MODERATOR, Role.ADMIN, Role.OWNER), (req, res, next) => upload.single('apk')(req, res, err => err ? res.status(400).json({ error: err.message }) : next()), async (req: AuthRequest, res) => {
  const parsed = z.object({ name: z.string().min(2).max(70), description: z.string().min(20).max(1500), category: z.enum(['Games', 'Design', 'Tools', 'Development', 'Education', 'Other']), version: z.string().min(1).max(20).optional() }).safeParse(req.body);
  if (!parsed.success || !req.file) { if (req.file) fs.unlinkSync(req.file.path); return res.status(400).json({ error: 'Valid product details and an APK file are required.' }); }
  const fileBuffer = fs.readFileSync(req.file.path);
  // APKs are ZIP containers. This checks the container signature only, not malware safety.
  const zipSignature = fileBuffer.length > 4 && fileBuffer[0] === 0x50 && fileBuffer[1] === 0x4b;
  if (!zipSignature) { fs.unlinkSync(req.file.path); return res.status(400).json({ error: 'The uploaded file is not a valid ZIP-based APK container.' }); }
  const sha256 = crypto.createHash('sha256').update(fileBuffer).digest('hex');
  const safeName = `${crypto.randomUUID()}.apk`; const finalPath = path.join(UPLOAD_DIR, safeName); fs.renameSync(req.file.path, finalPath);
  const product = await prisma.product.create({ data: { ...parsed.data, platforms: ['ANDROID'], downloadUrl: `/api/files/${safeName}`, fileSha256: sha256, status: ProductStatus.SUBMITTED, creatorId: req.auth!.id } });
  await audit(req.auth!.id, 'PRODUCT_SUBMITTED', 'Product', product.id, { sha256, fileSize: req.file.size, scan: 'ZIP signature checked; malware scan not available; human review required' });
  res.status(201).json({ product, verification: { status: 'SUBMITTED', sha256, note: 'Container signature and SHA-256 checked. This is not an antivirus scan. An administrator must review the app before publication.' } });
});
app.get('/api/files/:filename', async (req, res) => {
  const filename = path.basename(req.params.filename); const product = await prisma.product.findFirst({ where: { downloadUrl: `/api/files/${filename}` } });
  if (!product || product.status !== ProductStatus.PUBLISHED) return res.status(404).json({ error: 'File not found' });
  const filePath = path.join(UPLOAD_DIR, filename); if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File unavailable' });
  res.download(filePath, `${product.name.replace(/[^a-z0-9-_]/gi, '_')}.apk`);
});

app.get('/api/admin/queue', authenticate, allow(Role.MODERATOR, Role.ADMIN, Role.OWNER), async (_req, res) => {
  const [products, applications] = await Promise.all([
    prisma.product.findMany({ where: { status: { in: [ProductStatus.SUBMITTED, ProductStatus.UNDER_REVIEW] } }, include: { creator: { select: { displayName: true, email: true } } }, orderBy: { createdAt: 'asc' } }),
    prisma.creatorApplication.findMany({ where: { status: 'PENDING' }, include: { user: { select: { email: true, displayName: true } } }, orderBy: { createdAt: 'asc' } })
  ]); res.json({ products, applications });
});
app.post('/api/admin/products/:id/review', authenticate, allow(Role.MODERATOR, Role.ADMIN, Role.OWNER), async (req: AuthRequest, res) => {
  const parsed = z.object({ decision: z.enum(['APPROVE', 'REJECT']), note: z.string().max(500).optional() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid review decision' });
  const product = await prisma.product.findUnique({ where: { id: req.params.id } }); if (!product) return res.status(404).json({ error: 'Product not found' });
  const status = parsed.data.decision === 'APPROVE' ? ProductStatus.PUBLISHED : ProductStatus.REJECTED;
  const updated = await prisma.product.update({ where: { id: product.id }, data: { status } });
  await audit(req.auth!.id, `PRODUCT_${parsed.data.decision}D`, 'Product', product.id, { note: parsed.data.note || '' }); res.json({ product: updated });
});
app.post('/api/admin/creators/:id/review', authenticate, allow(Role.ADMIN, Role.OWNER), async (req: AuthRequest, res) => {
  const parsed = z.object({ decision: z.enum(['APPROVE', 'REJECT']) }).safeParse(req.body); if (!parsed.success) return res.status(400).json({ error: 'Invalid decision' });
  const application = await prisma.creatorApplication.findUnique({ where: { id: req.params.id } }); if (!application || application.status !== 'PENDING') return res.status(404).json({ error: 'Pending application not found' });
  await prisma.$transaction(async tx => {
    await tx.creatorApplication.update({ where: { id: application.id }, data: { status: parsed.data.decision === 'APPROVE' ? 'APPROVED' : 'REJECTED', reviewedBy: req.auth!.id, reviewedAt: new Date() } });
    if (parsed.data.decision === 'APPROVE') await tx.user.update({ where: { id: application.userId }, data: { role: Role.CREATOR, verified: true, displayName: application.displayName } });
  });
  await audit(req.auth!.id, `CREATOR_${parsed.data.decision}D`, 'CreatorApplication', application.id); res.json({ success: true });
});
app.get('/api/admin/audit', authenticate, allow(Role.ADMIN, Role.OWNER), async (_req, res) => {
  const logs = await prisma.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 100 }); res.json({ logs });
});
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => { console.error(err.message); res.status(400).json({ error: 'Request could not be processed' }); });
app.listen(PORT, () => console.log(`TC STORE API listening on ${PORT}`));
