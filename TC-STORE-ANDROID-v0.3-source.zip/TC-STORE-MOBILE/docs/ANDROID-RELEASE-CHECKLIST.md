# TC STORE Android release checklist

## Build
- [ ] Install mobile dependencies with `npm install` inside `mobile/`.
- [ ] Set `EXPO_PUBLIC_API_URL` to the deployed HTTPS API URL.
- [ ] Run `npx eas-cli login` and `npx eas-cli build --platform android --profile preview` for an APK.
- [ ] Verify the EAS build completes and install the APK on a physical Android device.

## Backend
- [ ] Copy `.env.production.example` to `.env`; generate strong unique secrets.
- [ ] Run `docker compose up -d --build`.
- [ ] Run `docker compose exec api npx prisma db push --schema database/schema.prisma`.
- [ ] Create the first Owner with `docker compose exec api npx tsx scripts/create-owner.ts`.
- [ ] Put the API behind HTTPS and configure `ALLOWED_ORIGINS`.
- [ ] Add backups, monitoring, persistent private object storage, and distributed rate limiting.
- [ ] Add a real malware scanning service before accepting public APK uploads.

## Functional and security tests
- [ ] Test USER, CREATOR, MODERATOR, ADMIN, and OWNER authorization boundaries.
- [ ] Verify stale JWT role claims cannot preserve revoked privileges.
- [ ] Verify rejected and pending APKs cannot be downloaded by ordinary users.
- [ ] Verify approved products are visible and download links require authentication.
- [ ] Verify Creator applications require Admin approval.
- [ ] Verify uploaded APK SHA-256 values match the stored file.
- [ ] Test APK upload size/type validation and abuse throttling.
