# Build TC STORE APK

This folder is the Expo Android app root.

1. Install Node.js 22 or newer.
2. Copy `.env.example` to `.env` and set `EXPO_PUBLIC_API_URL` to your deployed HTTPS backend URL.
3. Run `npm install`.
4. Sign in to Expo: `npx eas-cli login`.
5. Build an installable APK: `npx eas-cli build --platform android --profile preview`.
6. Open the build link returned by EAS on the Android phone and install after Android's normal confirmation.

The `preview` profile is configured to create an APK. The `production` profile creates an AAB for Google Play. EAS performs the Android build on its cloud infrastructure, so an Android SDK/Gradle installation is not required on the local machine, but network access and an Expo account are required.
